import React from 'react'
import './App.css'
import Navbar from './Components/Navbar'
import Container from './Components/Container'
import Grils from './Components/Map'
import Footer from './Components/Footer'
import FooterFo from './Components/FooterFo'
// import 'bootstrap/dist/css'
import 'bootstrap/dist/js/bootstrap.bundle'

// import Grids from './Components/grid'
const App = () => {
    return (
        <div className='App1 grid justify-items-center '>
            <div className='App2 w-[1100px] h-[1000px] -mb-10 bg-white grid justify-center '>
                <Navbar />
                <Container />
                <Grils />
            </div><br />
            <div className='sm:w-full sm:h-[50vh] row row-cols'>
                <Footer />
                <FooterFo />
            </div>
        </div>
    )
}

export default App
