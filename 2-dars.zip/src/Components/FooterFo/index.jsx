import React from 'react'
import '../../App.css'
function FooterFo() {
    return (
        <div className='FooterFo flex justify-center mb-0 p-0 items-center w-full h-[35px] text-sm  text-[#7BDAAE] bg-[#000000]'>
            <div className='flex items-center gap-1'>
                <h4 className='text-sm items-center mt-2'>Copyright © 2024</h4>
                <a href="#" className='text-sm text-[#7BDAAE]'>Your Company Name</a>
            </div>
        </div>
    )
}

export default FooterFo;